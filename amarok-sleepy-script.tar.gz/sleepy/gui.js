//This file is part of the sleepy amarok script.
//
//sleepy is free software: you can redistribute it and/or modify
//it under the terms of the GNU General Public License as published by
//the Free Software Foundation, either version 3 of the License, or
//(at your option) any later version.
//
//sleepy is distributed in the hope that it will be useful,
//but WITHOUT ANY WARRANTY; without even the implied warranty of
//MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//GNU General Public License for more details.
//
//You should have received a copy of the GNU General Public License
//along with Amarok.  If not, see <http://www.gnu.org/licenses/>.

Importer.loadQtBinding("qt.core");
Importer.loadQtBinding("qt.gui");
Importer.loadQtBinding("qt.uitools");

Importer.include("trigger.js");
Importer.include("action.js");

function Dialog() {
    var UIloader = new QUiLoader(this);
    var uiFile = new QFile (Amarok.Info.scriptPath() + "/gui.ui");
    uiFile.open(QIODevice.ReadOnly);
    this.dialog = UIloader.load(uiFile,this);
    this.show = this.dialog.show;
    this._init = _init;
    this.enable = enable;
    this.disable = disable;
    this.getAction = getAction;
    this.setTrigger = setTrigger;
    this.track = new Track();
    this.action = new Action();
    this._init();
    var x = this;
    this.track.disableButton = function() {x.disable();};
}

function _init() {
    var x = this;
    this.dialog.enable.toggled.connect(null, function() { x.enable();});
    this.dialog.disable.clicked.connect(null, function() { x.disable();});
    this.dialog.enable.clicked.connect(null, function() {x.dialog.hide();});
    this.dialog.infoEnabled.setVisible(false);
    this.dialog.triggerBox.stopTrigger.setChecked(true);
}

function disable() {
    this.dialog.enable.setChecked(false);
    this.dialog.disable.setChecked(true);
}

function enable() {
    var x = this;
    state = this.dialog.enable.checked;
    print(state);
    if (state==true) {
        print("before getTrigger");
        this.track = this.getAction();
        if (this.dialog.extraBox.screenOff.checked == true) {
            var time = 10;
            var a = function() {x.action.turnOffScreen();};
            this.track.timedAction(time, a);
        }
        print("after getTrigger");
        this.setTrigger(this.track);
        this.dialog.infoEnabled.setVisible(true);
        this.dialog.infoDisabled.setVisible(false);
    } else {
        print("stopped");
        this.dialog.infoEnabled.setVisible(false);
        this.dialog.infoDisabled.setVisible(true);
        this.track.stop();
    }
}

function getAction() {
    print("in getAction");
    var message;
    var x = this;
    var global_action_function;
	var amarok_action_function;
	var global_action = this.dialog.actionBox.global_action.currentIndex;
	var amarok_action = this.dialog.actionBox.amarok_action.currentIndex;

	//Set the global action
    if (global_action == 0) 
    {
		//None
		global_action_function = function() {};
		
	} 
	else 
	{
        if (global_action == 1) 
        {
			//Suspend to ram
			global_action_function = function() {x.action.shutdown();};
        } 
    }//
	//Set the amarok action
	if (amarok_action == 0) {
		//None
		amarok_action_function = function() {};
	} else {
		if (amarok_action == 1) {
			//Pause amarok
			amarok_action_function = function() {x.action.pause();};
		} else {
			if (amarok_action == 2) {
				//Stop amarok
				amarok_action_function = function() {x.action.stop();};
			} else {
				//Quit amarok
				amarok_action_function = function() {x.action.quit();};
			}
		}
	}

    this.track.setAction(global_action_function, amarok_action_function);
    print("returned track");
    return this.track;
}

function setTrigger(track) {
    print("in getTrigger");
    if (this.dialog.triggerBox.songsTrigger.checked==true) {
        print("songs trigger");
        var songs = this.dialog.triggerBox.songsFrame.nbOfSongs.value;
        print(songs);
        track.startSongsTrigger(songs);
    } else {
        if (this.dialog.triggerBox.stopTrigger.checked==true) {
            print("stop trigger");
            track.startStopTrigger();
        } else {
            if (this.dialog.triggerBox.timeTrigger.checked==true) {
                print("time trigger")
                var time = this.dialog.triggerBox.timeFrame.timeBox.value;
                var seconds = time * 60;
                track.startTimeTrigger(seconds);
            } else {
                print("nothing selected");
            }
        }
    }
}
