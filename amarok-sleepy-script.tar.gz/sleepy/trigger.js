//This file is part of the sleepy amarok script.
//
//sleepy is free software: you can redistribute it and/or modify
//it under the terms of the GNU General Public License as published by
//the Free Software Foundation, either version 3 of the License, or
//(at your option) any later version.
//
//sleepy is distributed in the hope that it will be useful,
//but WITHOUT ANY WARRANTY; without even the implied warranty of
//MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//GNU General Public License for more details.
//
//You should have received a copy of the GNU General Public License
//along with Amarok.  If not, see <http://www.gnu.org/licenses/>.

Importer.loadQtBinding( "qt.core" );

function Track() {
    this.init = init;
    this.init();
    this.trigger = "";
    this.triggerTime = "time";
    this.triggerStop = "stop";
    this.triggerSongs = "songs";
    x = this;
    Amarok.Engine.trackChanged.connect(function() { x.trackChanged();});
    Amarok.Engine.trackFinished.connect(function() { x.trackFinished();});
}
Track.prototype.trackChanged = trackChanged;
Track.prototype.trackFinished = trackFinished;
Track.prototype.timeTicked = timeTicked;
Track.prototype.startSongsTrigger = startSongsTrigger;
Track.prototype.startStopTrigger = startStopTrigger;
Track.prototype.startTimeTrigger = startTimeTrigger;
Track.prototype.stop = stop;
Track.prototype.setAction = setAction;
Track.prototype.action = action;

function init() {
    this.nbOfPlays = 0;
    this.currentTime = 0;
    this.enabled = false;
}

function setAction(global_action, amarok_action) {
    this._global_action = function() { global_action();};
    this._amarok_action = function() { amarok_action();};
	this._message = qsTranslate("trigger", "Executing action");
}

function action() {
    Amarok.Window.OSD.setText(this._message);
    Amarok.Window.OSD.show();
    //disable button clicked
    this.disableButton();
    this.stop();
	this._global_action();
    this._amarok_action();
}

function stop() {
    this.init();
    if (this.trigger == this.triggerTime) {
        this.timeTimer.stop();
    }
}

function startStopTrigger() {
    this.trigger = this.triggerStop;
    this.enabled = true;
}

function startSongsTrigger(nbOfSongs) {
    this.trigger = this.triggerSongs;
    this.enabled = true;
    this.nbOfSongsToPlay = nbOfSongs;
}

function startTimeTrigger(time) {
    this.trigger = this.triggerTime;
    this.enabled = true;
    this.time = time;
    this.timeTimer = new QTimer();
    var x = this;
    this.timeTimer.timeout.connect(function() { x.timeTicked(); });
    this.timeTimer.start(1000);
}

function timedAction(time, action) {
    this.timedActionTime = time;
    this.timedActionAction = action;
    this.actionTimer = new QTimer();
    var x = this;
    this.actionTimer.timeout.connect(function() { x.timedActionTick();});
    this.actionTimer.start(1000);
}
Track.prototype.timedAction = timedAction;

function timedActionTick() {
    this.timedActionTicks++;
    print("timed action tick");
    print(this.timedActionTime);
    print(this.timedActionTicks);
    if (this.timedActionTicks >= this.timedActionTime) {
        this.actionTimer.stop();
        this.timedActionTicks = 0;
        this.timedActionAction();
    }
}
Track.prototype.timedActionTick = timedActionTick;
Track.prototype.timedActionTicks = 0;

function timeTicked() {
    if (!this.enabled == true) {
        return;
    }
    this.currentTime++;
    if (this.currentTime >= this.time) {
        this.timeTimer.stop()
    }   
    if (this.trigger == this.triggerTime && this.currentTime >= this.time) {
        this.action();
    }
}


function trackChanged() {
    if (!this.enabled == true) {
        return;
    }
    //TODO count the length of the song before counting the song?
    this.nbOfPlays++;
    if (this.trigger == this.triggerSongs && this.nbOfPlays >= (this.nbOfSongsToPlay+1)) {
        this.action();
    }
}

function trackFinished() {
    if (!this.enabled == true) {
        return;
    }
    //remove one of nbOfPlays because you don't want to sleepy to act when you stop a song and that's the last song before suspend.
    this.nbOfPlays--;
    if (this.trigger == this.triggerStop) {
        this.action();
    }
}
