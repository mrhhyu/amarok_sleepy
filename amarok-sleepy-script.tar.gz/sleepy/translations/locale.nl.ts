<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="nl">
<context>
    <name>Sleepy</name>
    <message>
        <location filename="../gui.ui" line="14"/>
        <source>Sleepy...</source>
        <translation>Slaperig...</translation>
    </message>
    <message>
        <location filename="../gui.ui" line="26"/>
        <source>Disable</source>
        <translation>Uitzetten</translation>
    </message>
    <message>
        <location filename="../gui.ui" line="48"/>
        <source>Enable</source>
        <translation>Aanzetten</translation>
    </message>
    <message>
        <location filename="../gui.ui" line="67"/>
        <source>When should sleepy act?</source>
        <translation>Wanneer moet sleepy uitgevoerd worden?</translation>
    </message>
    <message>
        <location filename="../gui.ui" line="79"/>
        <source>Based on songs played</source>
        <translation>Op basis van het aantal gespeelde liedjes</translation>
    </message>
    <message>
        <location filename="../gui.ui" line="92"/>
        <source>Based on time played</source>
        <translation>Op basis van de gespeelde tijd</translation>
    </message>
    <message>
        <location filename="../gui.ui" line="105"/>
        <source>After play stopped</source>
        <translation>Wanneer de muziek stopt</translation>
    </message>
    <message>
        <location filename="../gui.ui" line="133"/>
        <source> songs</source>
        <translation> liedjes</translation>
    </message>
    <message>
        <location filename="../gui.ui" line="136"/>
        <location filename="../gui.ui" line="171"/>
        <source>after </source>
        <translation>na </translation>
    </message>
    <message>
        <location filename="../gui.ui" line="168"/>
        <source> minutes</source>
        <translation> minuten</translation>
    </message>
    <message>
        <location filename="../gui.ui" line="189"/>
        <source>What should sleepy do?</source>
        <translation>Wat moet sleepy doen?</translation>
    </message>
    <message>
        <location filename="../gui.ui" line="205"/>
        <location filename="../gui.ui" line="238"/>
        <source>None</source>
        <translation>Niets</translation>
    </message>
    <message>
        <location filename="../gui.ui" line="210"/>
        <source>Suspend to Ram</source>
        <translation>slaapstand (in het geheugen)</translation>
    </message>
    <message>
        <location filename="../gui.ui" line="215"/>
        <source>Suspend to Disk</source>
        <translation>slaapstand (naar schijf)</translation>
    </message>
    <message>
        <location filename="../gui.ui" line="220"/>
        <source>Shutdown</source>
        <translation>Afsluiten</translation>
    </message>
    <message>
        <location filename="../gui.ui" line="243"/>
        <source>Pause Amarok</source>
        <translation>Pauzeer Amarok</translation>
    </message>
    <message>
        <location filename="../gui.ui" line="248"/>
        <source>Stop Amarok</source>
        <translation>Stop Amarok</translation>
    </message>
    <message>
        <location filename="../gui.ui" line="253"/>
        <source>Quit Amarok</source>
        <translation>Sluit Amarok</translation>
    </message>
    <message>
        <location filename="../gui.ui" line="267"/>
        <source>Global actions</source>
        <translation>Globale acties</translation>
    </message>
    <message>
        <location filename="../gui.ui" line="280"/>
        <source>Amarok actions</source>
        <translation>Acties voor Amarok</translation>
    </message>
    <message>
        <location filename="../gui.ui" line="385"/>
        <source>Sleepy is disabled.</source>
        <translation>Sleepy is uitgeschakeld.</translation>
    </message>
    <message>
        <location filename="../gui.ui" line="492"/>
        <source>Sleepy is enabled.</source>
        <translation>Sleepy is geactiveerd.</translation>
    </message>
    <message>
        <location filename="../gui.ui" line="505"/>
        <source>Extra configuration</source>
        <translation>Extra configuratie</translation>
    </message>
    <message>
        <location filename="../gui.ui" line="517"/>
        <source>Turns the screen off after 10 seconds.</source>
        <translation>Zet het scherm af na 10 seconden.</translation>
    </message>
    <message>
        <location filename="../gui.ui" line="520"/>
        <source>Turn off the screen</source>
        <translation>Zet het scherm af</translation>
    </message>
</context>
<context>
    <name>trigger</name>
    <message>
        <location filename="../trigger.js" line="48"/>
        <source>Executing action</source>
        <translation>Voer een actie uit</translation>
    </message>
</context>
</TS>
