<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="fr_FR">
<context>
    <name>Sleepy</name>
    <message>
        <source>Sleepy...</source>
        <translation>Sleepy...</translation>
    </message>
    <message>
        <source>Disable</source>
        <translation>Désactiver</translation>
    </message>
    <message>
        <source>Enable</source>
        <translation>Activer</translation>
    </message>
    <message>
        <source>When should sleepy act?</source>
        <translation>Quand est ce que sleepy doit s&apos;activer?</translation>
    </message>
    <message>
        <source>Based on songs played</source>
        <translation>En fonction du nombre de chansons</translation>
    </message>
    <message>
        <source>Based on time played</source>
        <translation>En fonction du temps</translation>
    </message>
    <message>
        <source>After play stopped</source>
        <translation>Après la fin de la lecture</translation>
    </message>
    <message>
        <source> songs</source>
        <translation> chansons</translation>
    </message>
    <message>
        <source>after </source>
        <translation>après </translation>
    </message>
    <message>
        <source> minutes</source>
        <translation> minutes</translation>
    </message>
    <message>
        <source>What should sleepy do?</source>
        <translation>Que doit faire sleepy?</translation>
    </message>
    <message>
        <source>None</source>
        <translation>Aucun</translation>
    </message>
    <message>
        <source>Suspend to Ram</source>
        <translation>Mettre en veille (en mémoire)</translation>
    </message>
    <message>
        <source>Suspend to Disk</source>
        <translation>Mettre en veille prolongée (sur disque)</translation>
    </message>
    <message>
        <source>Shutdown</source>
        <translation>Éteindre</translation>
    </message>
    <message>
        <source>Pause Amarok</source>
        <translation>Mettre en pause Amarok</translation>
    </message>
    <message>
        <source>Stop Amarok</source>
        <translation>Arrêter Amarok</translation>
    </message>
    <message>
        <source>Quit Amarok</source>
        <translation>Quitter Amarok</translation>
    </message>
    <message>
        <source>Global actions</source>
        <translation>Actions générales</translation>
    </message>
    <message>
        <source>Amarok actions</source>
        <translation>Actions d&apos;Amarok</translation>
    </message>
    <message>
        <source>Sleepy is disabled.</source>
        <translation>Sleepy est désactivé.</translation>
    </message>
    <message>
        <source>Sleepy is enabled.</source>
        <translation>Sleepy est activé.</translation>
    </message>
    <message>
        <source>Extra configuration</source>
        <translation>Configuration supplémentaire</translation>
    </message>
    <message>
        <source>Turns the screen off after 10 seconds.</source>
        <translation>Éteindre l&apos;écran après 10 secondes.</translation>
    </message>
    <message>
        <source>Turn off the screen</source>
        <translation>Éteindre l&apos;écran</translation>
    </message>
</context>
<context>
    <name>trigger</name>
    <message>
        <source>Executing action</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
