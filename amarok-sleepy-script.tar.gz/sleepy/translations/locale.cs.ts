<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="cs_CZ">
<context>
    <name>Sleepy</name>
    <message>
        <location filename="../gui.ui" line="14"/>
        <source>Sleepy...</source>
        <translation>Sleepy...</translation>
    </message>
    <message>
        <location filename="../gui.ui" line="26"/>
        <source>Disable</source>
        <translation>Zakázat</translation>
    </message>
    <message>
        <location filename="../gui.ui" line="48"/>
        <source>Enable</source>
        <translation>Povolit</translation>
    </message>
    <message>
        <location filename="../gui.ui" line="67"/>
        <source>When should sleepy act?</source>
        <translation>Kdy má Sleepy jednat?</translation>
    </message>
    <message>
        <location filename="../gui.ui" line="79"/>
        <source>Based on songs played</source>
        <translation>Vycházet z přehrávaných písní</translation>
    </message>
    <message>
        <location filename="../gui.ui" line="92"/>
        <source>Based on time played</source>
        <translation>Vycházet z přehrávaného času</translation>
    </message>
    <message>
        <location filename="../gui.ui" line="105"/>
        <source>After play stopped</source>
        <translation>Po zastavení přehrávání</translation>
    </message>
    <message>
        <location filename="../gui.ui" line="133"/>
        <source> songs</source>
        <translation> písně</translation>
    </message>
    <message>
        <location filename="../gui.ui" line="136"/>
        <location filename="../gui.ui" line="171"/>
        <source>after </source>
        <translation>po </translation>
    </message>
    <message>
        <location filename="../gui.ui" line="168"/>
        <source> minutes</source>
        <translation> minutách</translation>
    </message>
    <message>
        <location filename="../gui.ui" line="189"/>
        <source>What should sleepy do?</source>
        <translation>Co má Sleepy dělat?</translation>
    </message>
    <message>
        <location filename="../gui.ui" line="205"/>
        <location filename="../gui.ui" line="238"/>
        <source>None</source>
        <translation>Nic</translation>
    </message>
    <message>
        <location filename="../gui.ui" line="210"/>
        <source>Suspend to Ram</source>
        <translation>Odložit do RAM</translation>
    </message>
    <message>
        <location filename="../gui.ui" line="215"/>
        <source>Suspend to Disk</source>
        <translation>Odložit na disk</translation>
    </message>
    <message>
        <location filename="../gui.ui" line="220"/>
        <source>Shutdown</source>
        <translation>Zastavit provoz</translation>
    </message>
    <message>
        <location filename="../gui.ui" line="243"/>
        <source>Pause Amarok</source>
        <translation>Pozastavit Amarok</translation>
    </message>
    <message>
        <location filename="../gui.ui" line="248"/>
        <source>Stop Amarok</source>
        <translation>Zastavit Amarok</translation>
    </message>
    <message>
        <location filename="../gui.ui" line="253"/>
        <source>Quit Amarok</source>
        <translation>Ukončit Amarok</translation>
    </message>
    <message>
        <location filename="../gui.ui" line="267"/>
        <source>Global actions</source>
        <translation>Všeobecné kroky</translation>
    </message>
    <message>
        <location filename="../gui.ui" line="280"/>
        <source>Amarok actions</source>
        <translation>Činnosti spojené s Amarokem</translation>
    </message>
    <message>
        <location filename="../gui.ui" line="385"/>
        <source>Sleepy is disabled.</source>
        <translation>Sleepy je zakázán.</translation>
    </message>
    <message>
        <location filename="../gui.ui" line="492"/>
        <source>Sleepy is enabled.</source>
        <translation>Sleepy je povolen.</translation>
    </message>
    <message>
        <location filename="../gui.ui" line="505"/>
        <source>Extra configuration</source>
        <translation>Další nastavení</translation>
    </message>
    <message>
        <location filename="../gui.ui" line="517"/>
        <source>Turns the screen off after 10 seconds.</source>
        <translation>Vypne obrazovku po deseti sekundách.</translation>
    </message>
    <message>
        <location filename="../gui.ui" line="520"/>
        <source>Turn off the screen</source>
        <translation>Vypnout obrazovku</translation>
    </message>
</context>
<context>
    <name>trigger</name>
    <message>
        <location filename="../trigger.js" line="48"/>
        <source>Executing action</source>
        <translation>Provádí se činnost</translation>
    </message>
</context>
</TS>
