//This file is part of the sleepy amarok script.
//
//sleepy is free software: you can redistribute it and/or modify
//it under the terms of the GNU General Public License as published by
//the Free Software Foundation, either version 3 of the License, or
//(at your option) any later version.
//
//sleepy is distributed in the hope that it will be useful,
//but WITHOUT ANY WARRANTY; without even the implied warranty of
//MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//GNU General Public License for more details.
//
//You should have received a copy of the GNU General Public License
//along with Amarok.  If not, see <http://www.gnu.org/licenses/>.

Importer.loadQtBinding( "qt.core" );

function Action() {
    this.shutdown = shutdown;
    this.execute = execute;
    this.pause = pause;
    this.stop = stop;
	this.quit = quit;
	this.turnOffScreen = turnOffScreen;
}

function shutdown() {
    var shutdown = "shutdown -h now";
    this.execute(shutdown);
}

function turnOffScreen() {
	print("lock screen");
    var lockScreen = "xset dpms force off";
    this.execute(lockScreen);
}

function pause() {
	Amarok.Engine.Pause();
}

function stop() {
    Amarok.Engine.Stop(true);
}

function quit() {
	var quitDbus = "qdbus org.kde.amarok /MainApplication org.kde.KApplication.quit";
	this.execute(quitDbus);
}

function execute(p) {
    //print("execute:::");
    print(p); 
	var process = new QProcess();
	process.start(p);
}
