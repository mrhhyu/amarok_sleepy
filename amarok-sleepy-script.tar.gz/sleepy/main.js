//This file is part of the sleepy amarok script.
//
//sleepy is free software: you can redistribute it and/or modify
//it under the terms of the GNU General Public License as published by
//the Free Software Foundation, either version 3 of the License, or
//(at your option) any later version.
//
//sleepy is distributed in the hope that it will be useful,
//but WITHOUT ANY WARRANTY; without even the implied warranty of
//MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//GNU General Public License for more details.
//
//You should have received a copy of the GNU General Public License
//along with Amarok.  If not, see <http://www.gnu.org/licenses/>.

Importer.loadQtBinding("qt.core");
Importer.loadQtBinding("qt.gui");
Importer.loadQtBinding("qt.uitools");

Importer.include("trigger.js");
Importer.include("action.js");
Importer.include("gui.js");

//Get the system language
const lang = QLocale.system().name();

//
function qsTranslate(context,st){
    return QCoreApplication.translate(context,st);
}


var translator = new QTranslator();
translator.load("locale." + lang, Amarok.Info.scriptPath()+"/translations");
QCoreApplication.installTranslator(translator);

var dialog = new Dialog();

Amarok.Window.addToolsMenu("startSleepyTimer", "Sleepy");
Amarok.Window.ToolsMenu.startSleepyTimer["triggered()"].connect(Amarok.Window.ToolsMenu.startSleepytimer, dialog.show);
